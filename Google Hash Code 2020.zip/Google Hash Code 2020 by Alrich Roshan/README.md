# Google Hash Code 2020
My solutions for Google's 2020 Hash Code Practice Round. All written in pure C.

## Scores
- A - example: 16
- B - small: 100
- C - medium: 4,500
- D - quite big: 999,999,932
- E - also big: 505,000,000
